import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-enquiry',
  templateUrl: './main-enquiry.component.html',
  styleUrls: ['./main-enquiry.component.scss']
})
export class MainEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
