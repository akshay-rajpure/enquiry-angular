export interface IEnquiryModel {
    enquiryId: string
    subject: string
    courseName: string
    enquiryDetails: string
    status: string
}