export interface ILoginModel {
    role: string
    email: String
    password: string
}