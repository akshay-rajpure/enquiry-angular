export interface IRegistrationModel {
    role: string
    firstname: string
    lastname: string
    email: string
    phone: number
    gender: string
    password: string
    courseName:string
}